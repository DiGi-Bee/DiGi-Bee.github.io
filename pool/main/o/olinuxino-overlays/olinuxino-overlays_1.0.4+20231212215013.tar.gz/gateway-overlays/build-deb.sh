#!/bin/sh

PROJECT_NAME=digibee

sed -i "s/BUILD_DATE/$(date +%Y%m%d%H%M%S)/g" debian/changelog
dpkg-buildpackage --post-clean -uc -us --compression=gzip
mkdir $PROJECT_NAME && cp -vf ../olinuxino-overlays_*.* $PROJECT_NAME/

reprepro -b ../DiGi-Bee.github.io/ --ignore=wrongdistribution include bullseye $PROJECT_NAME/*.changes
rm -rvf $PROJECT_NAME
